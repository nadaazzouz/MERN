const express = require('express');

const router = express.Router();

const articleController = require('../controllers/articleController');

// GET /api/articles
router.get('/', articleController.getAllArticles);

// GET /api/articles/:id
router.get('/:id', articleController.getArticleById);

// POST /api/articles
router.post('/', articleController.createArticle);

router.put('/:id', articleController.updateArticle);
router.delete('/:id', articleController.deleteArticle);
module.exports = router;